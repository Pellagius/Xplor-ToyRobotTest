import GameController

if __name__ == '__main__':
    GameController.begin()